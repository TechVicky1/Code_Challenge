﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Pacman.Entity;

namespace Pacman.Control
{
    public class CommandHandler
    {
        private CommandState availableCommands;

        public CommandHandler()
        {
            availableCommands = new DynamicState();
        }

        public CommandResponse ProcessTurn(String userInput, Player thePlayer)
        {
            availableCommands = availableCommands.Update(thePlayer);


            ParsedInput validInput = parse(userInput);

            Command theCommand = availableCommands.GetCommand(validInput.Command);
            if (theCommand == null)
                return new CommandResponse("Not a valid command");
            return theCommand.Execute(validInput, thePlayer);
        }

        private ParsedInput parse(String userInput)
        {
            Console.WriteLine("*************");
            Console.Write(" Commands ::");
            foreach (string k in availableCommands.GetLabels())
            {
                Console.Write("[" + k + "] ");
            }
            Console.WriteLine("\n*************");
            Parser theParser = new Parser(availableCommands.GetLabels());
            return theParser.Parse(userInput);
        }
    }
}
