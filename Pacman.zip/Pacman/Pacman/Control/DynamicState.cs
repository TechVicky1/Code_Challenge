﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Pacman.Entity;

namespace Pacman.Control
{
    public class DynamicState : CommandState
    {
        public DynamicState()
            : base()
        {
            AvailableCommands.Add("go", new MoveCommand());
            AvailableCommands.Add("quit", new QuitCommand());
            AvailableCommands.Add("move", new MoveCommand());
            AvailableCommands.Add("report", new ReportCommand());
        }

        public override CommandState Update(Player thePlayer)
        {
            return this;
        }
    }
}
