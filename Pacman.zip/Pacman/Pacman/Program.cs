﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Pacman.Control;

namespace Pacman
{
    class Program
    {
        static void Main(string[] args)
        {
            ControlPacman controlpacman = new ControlPacman();
            controlpacman.RunGame();
        }
    }
}
