﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Pacman.Entity;

namespace Pacman.Boundary
{
    public interface IPacmanData
    {
        Location GetStartingLocation();
        String GetWelcomeMessage();
    }
}
