﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections;

namespace Pacman.Entity
{
    public class Location
    {
        private Hashtable exits;
        private String description;
        private String label;

        public Location(String description, String label) : this()
        {
            Description = description;
            Label = label;
            exits = new Hashtable();
        }

        public Location()
        {
        }

        public Boolean AddExit(String exitLabel, Exit theExit)
        {
            if (exits.ContainsKey(exitLabel))
                return false;
            exits.Add(exitLabel, theExit);
            return true;
        }

        public Exit GetExit(String exitLabel)
        {
            return (Exit)exits[exitLabel];
        }

        public bool ContainsExit(String exitLabel)
        {
            return exits.Contains(exitLabel);
        }

        public String Description
        {
            get { return description; }
            set { description = value; }
        }

        public String Label
        {
            get { return label; }
            set { label = value; }
        }

        public String AvailableExits()
        {
            StringBuilder returnMsg = new StringBuilder();
            foreach (string label in this.exits.Keys)
            {
                returnMsg.Append("[" + label + "] ");
            }
            return returnMsg.ToString();
        }

        public override string ToString()
        {
            return "**********\n" + this.Label + "\n**********\n"
                + "Exits found :: " + AvailableExits()
                + "\n***********\n"
                + this.Description + "\n**********\n";
        }

    }
}
