﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Pacman.Boundary;

namespace InterfaceImpl
{
    public class ConsoleInterface : IPacmanClient
    {
        public ConsoleInterface()
        {
            Console.Title = "Vivek's Pacman game";
            Console.WindowWidth = 100;
            Console.ForegroundColor = ConsoleColor.White;   
        }

        public String GetReply(String question)
        {
            Console.Out.Write("\n" + question + " ");
            return Console.In.ReadLine();
        }

        public void PlayerMessage(String message)
        {
            Console.Out.Write(message);
        }

        public String GetCommand()
        {
            Console.Out.Write("\n\n>>> ");
            return Console.In.ReadLine();
        }
    }
}
